#!/bin/bash

echo "load data from dwd to dws start ......"
hive -f dwd-to-dws.sql
-- load data to qfbap_dws.dws_user_visit_month1
FROM
(SELECT
c.user_id,
c.type,
c.cnt,
c.content,
row_number() over(PARTITION BY c.user_id,c.type ORDER BY c.cnt DESC) as rn,
c.dw_date
from
(select 
b.user_id as user_id,
b.type as type,
sum(b.pv) as cnt,
b.content as content,
from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss') as dw_date
from
(select
user_id,
split(types,':')[0] as type,
pv,
split(types,':')[1] as content
from
(select user_id,
concat('visit_ip',':',visit_ip,',','cookie_id',':',cookie_id,',','浏览器',':',browser_name,',','操作系统',':',visit_os) as type,
pv
from qfbap_dwd.dwd_user_pc_pv) a lateral view explode(split(a.type,','))type as types) b
group by
b.user_id,
b.type,
b.content) c
) d
INSERT overwrite table qfbap_dws.dws_user_visit_month1 PARTITION(dt='20190710')
SELECT *
;
#!/bin/bash

echo "load data from dwd to dm start ......"
hive -f dwd-to-dm_user_basic.sql
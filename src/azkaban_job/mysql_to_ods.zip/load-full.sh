#!/bin/bash

##run job
echo "sqoop job load-full start ......"
sqoop job -exec bap_code_category
sqoop job -exec bap_user
sqoop job -exec bap_user_extend
sqoop job -exec bap_user_addr
echo "sqoop job load-full over ......load data into hive start ......"
hive -e "load data inpath '/qfbap/ods_tmp/ods_code_category/*' into table qfbap_ods.ods_code_category"
hive -e "load data inpath '/qfbap/ods_tmp/ods_user/*' into table qfbap_ods.ods_user"
hive -e "load data inpath '/qfbap/ods_tmp/ods_user_extend/*' into table qfbap_ods.ods_user_extend"
hive -e "load data inpath '/qfbap/ods_tmp/ods_user_addr/*' into table qfbap_ods.ods_user_addr"
echo "load data over ......"
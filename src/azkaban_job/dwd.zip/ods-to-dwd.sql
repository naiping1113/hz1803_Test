-- qfbap_dwd.dwd_biz_trade
FROM qfbap_ods.ods_biz_trade
insert overwrite table qfbap_dwd.dwd_biz_trade PARTITION(dt)
SELECT *,from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss');

-- qfbap_dwd.dwd_cart
FROM qfbap_ods.ods_cart
insert overwrite table qfbap_dwd.dwd_cart PARTITION(dt)
SELECT *,from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss');

-- qfbap_dwd.dwd_code_category
FROM qfbap_ods.ods_code_category
insert overwrite table qfbap_dwd.dwd_code_category
SELECT *,from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss');

-- qfbap_dwd.dwd_order_delivery
FROM qfbap_ods.ods_order_delivery
insert overwrite table qfbap_dwd.dwd_order_delivery PARTITION(dt)
SELECT *,from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss');

-- qfbap_dwd.dwd_order_item
FROM qfbap_ods.ods_order_item
insert overwrite table qfbap_dwd.dwd_order_item PARTITION(dt)
SELECT *,from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss');

-- qfbap_dwd.dwd_us_order
FROM qfbap_ods.ods_us_order
insert overwrite table qfbap_dwd.dwd_us_order PARTITION(dt)
SELECT *,from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss');

-- qfbap_dwd.dwd_user
FROM qfbap_ods.ods_user
insert overwrite table qfbap_dwd.dwd_user
SELECT *,from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss');

-- qfbap_dwd.dwd_user_addr
FROM qfbap_ods.ods_user_addr
insert overwrite table qfbap_dwd.dwd_user_addr
SELECT *,from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss');

-- qfbap_dwd.dwd_user_extend
FROM qfbap_ods.ods_user_extend
insert overwrite table qfbap_dwd.dwd_user_extend
SELECT *,from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss');

-- qfbap_dwd.dwd_user_app_pv
FROM
(
SELECT
log_id,
user_id,
imei,
log_time,
HOUR(log_time) as log_hour,
visit_os,
os_version,
app_name,
app_version,
device_token,
visit_ip,
province,
city,
from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')
FROM qfbap_ods.ods_user_app_click_log) temp
insert overwrite table qfbap_dwd.dwd_user_app_pv PARTITION(dt='20190710')
SELECT *;

-- qfbap_dwd.dwd_user_pc_pv
FROM
(
SELECT
min(log_id) as log_id,
user_id,
session_id,
cookie_id,
min(visit_time),
max(visit_time),
case when max(visit_time) = min(visit_time) then 3 else max(visit_time) - min(visit_time) END as stay_time,
count(1) as pv,
visit_os,
browser_name,
visit_ip,
province,
city,
from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss')
FROM
qfbap_ods.ods_user_pc_click_log oupcl
GROUP BY log_id,user_id,session_id,cookie_id,visit_os,browser_name,visit_ip,province,city) temp
INSERT overwrite TABLE qfbap_dwd.dwd_user_pc_pv partition(dt='20190710')
SELECT *;
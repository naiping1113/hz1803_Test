#!/bin/bash

echo "load data from dwd to dm start ......"
hive -f dm_user_basic.sql
hive -f dm_user_visit.sql
#!/bin/bash

#run with args.eg: ./load_data.sh 2018-12-25
args=$1
dt=
if [ ${#args} == 0 ]
then
dt=`date -d "1 days ago" "+%Y%m%d"`
else
dt=$1
fi

##run job
echo "sqoop job load-incr start ......"
sqoop job -exec bap_us_order
sqoop job -exec bap_user_pc_click_log
sqoop job -exec bap_user_app_click_log
sqoop job -exec bap_order_item
sqoop job -exec bap_order_delivery
sqoop job -exec bap_cart
sqoop job -exec bap_biz_trade
echo "sqoop job load-incr over ......load into hive start ......"
hive -e "load data inpath '/qfbap/ods_tmp/ods_us_order/*' into table qfbap_ods.ods_us_order partition(dt=${dt})";
hive -e "load data inpath '/qfbap/ods_tmp/ods_user_pc_click_log/*' into table qfbap_ods.ods_user_pc_click_log partition(dt=${dt})";
hive -e "load data inpath '/qfbap/ods_tmp/ods_user_app_click_log/*' into table qfbap_ods.ods_user_app_click_log partition(dt=${dt})";
hive -e "load data inpath '/qfbap/ods_tmp/ods_order_item/*' into table qfbap_ods.ods_order_item partition(dt=${dt})";
hive -e "load data inpath '/qfbap/ods_tmp/ods_order_delivery/*' into table qfbap_ods.ods_order_delivery partition(dt=${dt})";
hive -e "load data inpath '/qfbap/ods_tmp/ods_cart/*' into table qfbap_ods.ods_cart partition(dt=${dt})";
hive -e "load data inpath '/qfbap/ods_tmp/ods_biz_trade/*' into table qfbap_ods.ods_biz_trade partition(dt=${dt})";
echo "load into hive over ......"
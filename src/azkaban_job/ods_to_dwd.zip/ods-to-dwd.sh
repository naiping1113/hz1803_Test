#!/bin/bash

echo "load data from ods to dwd start ......"
hive -f ods-to-dwd.sql